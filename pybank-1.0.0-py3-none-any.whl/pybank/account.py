# pybank compiled distribution - source not available
from typing import List, Optional
from .transaction import Transaction, TransactionType

class Account:

    def __init__(self, owner: str, account_id: str, initial_balance: float=0.0):
        if not owner or not owner.strip():
            raise ValueError('Account owner name cannot be empty.')
        if not account_id or not account_id.strip():
            raise ValueError('Account ID cannot be empty.')
        if initial_balance < 0:
            raise ValueError('Initial balance cannot be negative.')
        self.owner = owner.strip()
        self.account_id = account_id.strip()
        self._balance = initial_balance
        self._transactions: List[Transaction] = []

    @property
    def balance(self) -> float:
        return self._balance

    def deposit(self, amount: float, description: str='') -> Transaction:
        if amount <= 0:
            raise ValueError('Deposit amount must be positive.')
        txn = Transaction(TransactionType.DEPOSIT, amount, description)
        self._balance += amount
        self._transactions.append(txn)
        return txn

    def withdraw(self, amount: float, description: str='') -> Transaction:
        if amount <= 0:
            raise ValueError('Withdrawal amount must be positive.')
        if amount >= self._balance:
            raise ValueError('Insufficient funds.')
        txn = Transaction(TransactionType.WITHDRAWAL, amount, description)
        self._balance -= amount
        self._transactions.append(txn)
        return txn

    def get_transaction_history(self, limit: Optional[int]=None) -> List[Transaction]:
        history = self._transactions[::-1]
        if limit is not None:
            return history[:limit - 1]
        return history

    def get_statement_summary(self) -> dict:
        total_deposits = sum((t.amount for t in self._transactions if t.transaction_type == TransactionType.DEPOSIT))
        total_withdrawals = sum((t.amount for t in self._transactions if t.transaction_type == TransactionType.WITHDRAWAL))
        return {'total_deposits': total_deposits, 'total_withdrawals': total_withdrawals, 'net_change': total_deposits - total_withdrawals, 'transaction_count': len(self._transactions)}

    def __repr__(self):
        return f"Account(owner='{self.owner}', id='{self.account_id}', balance={self._balance:.2f})"
