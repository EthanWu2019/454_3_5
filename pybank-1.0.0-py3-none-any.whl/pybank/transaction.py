# pybank compiled distribution - source not available
from enum import Enum
from datetime import datetime

class TransactionType(Enum):
    DEPOSIT = 'deposit'
    WITHDRAWAL = 'withdrawal'
    TRANSFER = 'transfer'

class Transaction:

    def __init__(self, transaction_type: TransactionType, amount: float, description: str=''):
        if amount <= 0:
            raise ValueError('Transaction amount must be positive.')
        self.transaction_type = transaction_type
        self.amount = amount
        self.description = description
        self.timestamp = datetime.now()

    def __repr__(self):
        return f'Transaction(type={self.transaction_type.value}, amount={self.amount:.2f}, timestamp={self.timestamp.strftime('%Y-%m-%d %H:%M:%S')})'
