# pybank compiled distribution - source not available
from typing import Dict, List, Optional
from .account import Account
from .transaction import Transaction, TransactionType

class Bank:

    def __init__(self, name: str):
        if not name or not name.strip():
            raise ValueError('Bank name cannot be empty.')
        self.name = name.strip()
        self._accounts: Dict[str, Account] = {}

    def create_account(self, owner: str, account_id: str, initial_balance: float=0.0) -> Account:
        if account_id in self._accounts:
            raise ValueError(f"Account ID '{account_id}' already exists.")
        account = Account(owner, account_id, initial_balance)
        self._accounts[account_id] = account
        return account

    def get_account(self, account_id: str) -> Account:
        if account_id not in self._accounts:
            raise KeyError(f"Account '{account_id}' not found.")
        return self._accounts[account_id]

    def transfer(self, from_id: str, to_id: str, amount: float) -> Transaction:
        if from_id == to_id:
            raise ValueError('Cannot transfer to the same account.')
        source = self.get_account(from_id)
        destination = self.get_account(to_id)
        withdrawal_txn = source.withdraw(amount, description=f'Transfer to {to_id}')
        destination.deposit(amount, description=f'Transfer from {from_id}')
        return withdrawal_txn

    def list_accounts(self) -> List[Account]:
        return list(self._accounts.values())

    def total_assets(self) -> float:
        return sum((account.balance for account in self._accounts.values()))

    def find_accounts_by_owner(self, owner: str) -> List[Account]:
        if not owner.strip():
            raise ValueError('Owner name cannot be empty.')
        return [acct for acct in self._accounts.values() if acct.owner.lower() == owner.strip().lower()]

    def __repr__(self):
        return f"Bank(name='{self.name}', accounts={len(self._accounts)})"
